package com.suncraft.tcuscanner

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioManager
import android.media.ToneGenerator
import android.net.Uri
import android.os.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import android.widget.*
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import com.journeyapps.barcodescanner.ScanContract
import com.journeyapps.barcodescanner.ScanOptions
import java.io.File
import java.io.FileWriter
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : AppCompatActivity() {

    private lateinit var tvStatus: TextView
    private lateinit var btnScan: Button
    private lateinit var btnReset: Button
    private lateinit var btnShare: Button
    private lateinit var btnUndo: Button
    private lateinit var prefixInput: EditText
    private lateinit var startNumberInput: EditText
    private lateinit var rememberCheck: CheckBox

    private var prefix = ""
    private var currentNum = 0
    private val prefs by lazy { getSharedPreferences("suncraft_prefs", MODE_PRIVATE) }

    private val csvDir by lazy { File(getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS), "SuncraftTCU") }
    private val csvFile by lazy { File(csvDir, "registro.csv") }

    private val CAMERA_REQ = 11

    private val scanLauncher = registerForActivityResult(ScanContract()) { result ->
        if (result.contents != null) {
            handleResult(result.contents.trim())
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tvStatus = findViewById(R.id.tvStatus)
        btnScan = findViewById(R.id.btnScan)
        btnReset = findViewById(R.id.btnReset)
        btnShare = findViewById(R.id.btnShare)
        btnUndo = findViewById(R.id.btnUndo)
        prefixInput = findViewById(R.id.prefixInput)
        startNumberInput = findViewById(R.id.startNumberInput)
        rememberCheck = findViewById(R.id.rememberCheck)

        // Cargar último prefijo/número si el usuario lo desea
        val remembered = prefs.getBoolean("remember", false)
        rememberCheck.isChecked = remembered
        if (remembered) {
            prefix = prefs.getString("prefix", "") ?: ""
            currentNum = prefs.getInt("currentNum", 0)
            prefixInput.setText(prefix)
            startNumberInput.setText((currentNum + 1).toString())
            tvStatus.text = "Reanudado en: $prefix${currentNum + 1}"
        }

        btnScan.setOnClickListener {
            // Tomar valores si aún no hay prefijo
            if (prefix.isBlank()) {
                prefix = prefixInput.text.toString().trim()
                currentNum = (startNumberInput.text.toString().toIntOrNull() ?: 1) - 1
                if (prefix.isBlank()) {
                    toast("Introduce prefijo y número inicial")
                    return@setOnClickListener
                }
            }
            // Permiso de cámara
            if (!hasCameraPermission()) {
                ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.CAMERA), CAMERA_REQ)
                return@setOnClickListener
            }
            startScan()
        }

        btnUndo.setOnClickListener { undoLast() }
        btnShare.setOnClickListener { shareCsv() }
        btnReset.setOnClickListener { confirmReset() }

        rememberCheck.setOnCheckedChangeListener { _, isChecked ->
            prefs.edit().putBoolean("remember", isChecked).apply()
            if (isChecked) saveProgress() else clearProgress()
        }

        // Asegurar carpeta CSV
        if (!csvDir.exists()) csvDir.mkdirs()
        // Crear CSV con cabecera si no existe
        if (!csvFile.exists()) {
            FileWriter(csvFile, true).use { it.append("Secuencia,Codigo,FechaHora\n") }
        }
    }

    private fun startScan() {
        val options = ScanOptions()
        options.setDesiredBarcodeFormats(ScanOptions.ALL_CODE_TYPES)
        options.setPrompt("Enfoca la numeración (MAC)")
        options.setCameraId(0) // trasera
        options.setBeepEnabled(false)
        options.setOrientationLocked(true)
        scanLauncher.launch(options)
    }

    private fun handleResult(code: String) {
        if (!code.startsWith("13A2004")) {
            beepError()
            tvStatus.text = "⚠️ Inválido: $code"
            return
        }

        // Evitar duplicado inmediato: compara contra última línea del CSV
        val last = readLastLine()
        val lastCode = last?.substringAfter(",")?.substringBefore(",")?.trim()
        if (lastCode == code) {
            beepError()
            tvStatus.text = "⚠️ Duplicado (último guardado): $code"
            return
        }

        currentNum++
        val seq = "$prefix$currentNum"
        saveRow(seq, code)
        beepOk()
        tvStatus.text = "✅ $seq → $code"

        saveProgress()
    }

    private fun saveRow(seq: String, code: String) {
        val ts = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date())
        FileWriter(csvFile, true).use { it.append("$seq,$code,$ts\n") }
    }

    private fun readLastLine(): String? {
        if (!csvFile.exists()) return null
        return csvFile.readLines().lastOrNull()
    }

    private fun undoLast() {
        if (!csvFile.exists()) { toast("No hay CSV"); return }
        val lines = csvFile.readLines()
        if (lines.size <= 1) { toast("Nada que deshacer"); return } // solo cabecera
        val newContent = lines.dropLast(1).joinToString("\n")
        csvFile.writeText(newContent + if (newContent.endsWith("\n")) "" else "\n")
        if (currentNum > 0) currentNum--
        tvStatus.text = "🗑️ Último borrado. Siguiente: $prefix${currentNum + 1}"
        saveProgress()
    }

    private fun confirmReset() {
        AlertDialog.Builder(this)
            .setTitle("Restablecer")
            .setMessage("¿Borrar CSV y reiniciar numeración?")
            .setPositiveButton("Sí") { _, _ ->
                AlertDialog.Builder(this)
                    .setTitle("Confirmar")
                    .setMessage("Acción irreversible. ¿Seguro?")
                    .setPositiveButton("Sí") { _, _ ->
                        if (csvFile.exists()) csvFile.delete()
                        FileWriter(csvFile, true).use { it.append("Secuencia,Codigo,FechaHora\n") }
                        prefix = ""
                        currentNum = 0
                        clearProgress()
                        tvStatus.text = "🧾 CSV a 0. Introduce prefijo y número inicial."
                        beepError()
                    }
                    .setNegativeButton("No", null)
                    .show()
            }
            .setNegativeButton("No", null)
            .show()
    }

    private fun shareCsv() {
        if (!csvFile.exists()) { toast("No hay CSV para compartir"); return }
        val uri: Uri = FileProvider.getUriForFile(this, "${packageName}.fileprovider", csvFile)
        val sendIntent = Intent(Intent.ACTION_SEND).apply {
            type = "text/csv"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(Intent.createChooser(sendIntent, "Compartir registro.csv"))
    }

    private fun saveProgress() {
        if (!rememberCheck.isChecked) return
        prefs.edit()
            .putString("prefix", prefix)
            .putInt("currentNum", currentNum)
            .apply()
    }

    private fun clearProgress() {
        prefs.edit()
            .remove("prefix")
            .remove("currentNum")
            .apply()
    }

    private fun hasCameraPermission(): Boolean =
        ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED

    private fun beepOk() {
        val v = getSystemService(VIBRATOR_SERVICE) as Vibrator
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            v.vibrate(VibrationEffect.createOneShot(80, VibrationEffect.DEFAULT_AMPLITUDE))
        else v.vibrate(80)
        ToneGenerator(AudioManager.STREAM_MUSIC, 100).startTone(ToneGenerator.TONE_PROP_BEEP, 120)
    }

    private fun beepError() {
        val v = getSystemService(VIBRATOR_SERVICE) as Vibrator
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            v.vibrate(VibrationEffect.createOneShot(200, VibrationEffect.DEFAULT_AMPLITUDE))
        else v.vibrate(200)
        ToneGenerator(AudioManager.STREAM_MUSIC, 100).startTone(ToneGenerator.TONE_CDMA_SOFT_ERROR_LITE, 250)
    }

    private fun toast(msg:String){ Toast.makeText(this, msg, Toast.LENGTH_SHORT).show() }
}
